from __future__ import annotations

import sys
from pathlib import Path

from openai import OpenAI


KEYS_TXT = Path(__file__).resolve().parent / "keys.txt"
MODEL = "openai/gpt-oss-120b"
BASE_URL = "https://integrate.api.nvidia.com/v1"
TEST_MESSAGE = "Reply with exactly: OK"


def iter_keys(path: Path = KEYS_TXT):
    if not path.exists():
        print(f"keys file not found: {path}")
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        key = line.strip()
        if key:
            yield key


def test_key(key: str) -> bool:
    client = OpenAI(base_url=BASE_URL, api_key=key)
    try:
        completion = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": TEST_MESSAGE}],
            temperature=1,
            top_p=1,
            max_tokens=4096,
            stream=False,
        )
        message = completion.choices[0].message
        reasoning = getattr(message, "reasoning_content", None)
        content = message.content
        print(f"  [OK] {key[:20]}... -> {content!r}")
        if reasoning:
            print(f"    reasoning: {reasoning[:120]!r}")
        return True
    except Exception as exc:
        print(f"  [FAIL] {key[:20]}... -> {exc}")
        return False


def main() -> int:
    keys = list(iter_keys())
    if not keys:
        print("no keys found")
        return 1
    print(f"found {len(keys)} keys, testing {MODEL}...")
    ok = sum(1 for key in keys if test_key(key))
    print(f"\nresult: {ok}/{len(keys)} keys work")
    return 0 if ok == len(keys) else 1


if __name__ == "__main__":
    sys.exit(main())
